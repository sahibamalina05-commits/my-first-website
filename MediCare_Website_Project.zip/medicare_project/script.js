const medicines = [
  {name:"Paracetamol",category:"Pain relief",symbol:"✚",summary:"Commonly used to relieve pain and reduce fever.",uses:"Relief of mild to moderate pain and fever.",safety:"Taking too much can seriously damage the liver. Check other products for the same ingredient."},
  {name:"Ibuprofen",category:"Pain relief",symbol:"＋",summary:"A non-steroidal anti-inflammatory medicine (NSAID).",uses:"May be used for pain, inflammation and fever.",safety:"May not be suitable for people with stomach ulcers, kidney problems, or some other conditions. Ask a clinician."},
  {name:"Cetirizine",category:"Allergy",symbol:"✧",summary:"An antihistamine used for allergy symptoms.",uses:"May relieve sneezing, runny nose, itchy eyes and hives.",safety:"Can cause drowsiness in some people. Avoid driving if affected."},
  {name:"Omeprazole",category:"Digestive health",symbol:"◒",summary:"Reduces the amount of acid produced in the stomach.",uses:"Used for certain acid-related conditions, including reflux.",safety:"Persistent symptoms or long-term use should be discussed with a healthcare professional."},
  {name:"ORS",category:"Other",symbol:"◇",summary:"Oral rehydration salts help replace fluids and electrolytes.",uses:"Used to prevent or treat dehydration, including from diarrhoea.",safety:"Mix exactly as directed on the packet using safe water. Seek medical help for severe dehydration."},
  {name:"Amoxicillin",category:"Other",symbol:"▤",summary:"A prescription antibiotic in the penicillin family.",uses:"Treats certain bacterial infections when prescribed.",safety:"Does not treat viral infections. Use only when prescribed and follow the prescriber's instructions."}
];

const grid = document.getElementById("medicineGrid");
const searchInput = document.getElementById("searchInput");
const categoryFilter = document.getElementById("categoryFilter");
const count = document.getElementById("resultCount");
const empty = document.getElementById("emptyState");
const dialog = document.getElementById("medicineDialog");

function renderMedicines() {
  const term = searchInput.value.trim().toLowerCase();
  const category = categoryFilter.value;
  const filtered = medicines.filter(m =>
    (category === "all" || m.category === category) &&
    (m.name.toLowerCase().includes(term) || m.summary.toLowerCase().includes(term) || m.uses.toLowerCase().includes(term))
  );
  grid.innerHTML = filtered.map((m) => `
    <article class="medicine-card">
      <div class="card-top"><span class="medicine-symbol">${m.symbol}</span><span class="tag">${m.category}</span></div>
      <h3>${m.name}</h3><p>${m.summary}</p>
      <button class="details-btn" data-name="${m.name}">View information →</button>
    </article>`).join("");
  count.textContent = `${filtered.length} ${filtered.length === 1 ? "medicine" : "medicines"}`;
  empty.hidden = filtered.length !== 0;
}
function showDetails(name) {
  const m = medicines.find(item => item.name === name);
  if (!m) return;
  document.getElementById("dialogContent").innerHTML = `
    <span class="tag">${m.category}</span><h2>${m.name}</h2>
    <p><strong>General use:</strong> ${m.uses}</p>
    <p><strong>Important safety note:</strong> ${m.safety}</p>
    <p class="notice">This is general educational information, not a dose recommendation or personal medical advice. Consult a registered doctor or pharmacist.</p>`;
  dialog.showModal();
}
grid.addEventListener("click", e => {
  const btn = e.target.closest(".details-btn");
  if (btn) showDetails(btn.dataset.name);
});
searchInput.addEventListener("input", renderMedicines);
categoryFilter.addEventListener("change", renderMedicines);
document.getElementById("dialogClose").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", e => { if (e.target === dialog) dialog.close(); });
document.getElementById("contactForm").addEventListener("submit", e => {
  e.preventDefault();
  document.getElementById("formStatus").textContent = "Thanks! This demo form does not send data to a server.";
  e.target.reset();
});
renderMedicines();
