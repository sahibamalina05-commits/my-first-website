# MediCare — Medicine Information Website

## Files
- `index.html` — page structure
- `style.css` — responsive design and styling
- `script.js` — medicine data, search, category filter, details dialog and demo contact form

## Run the project
1. Extract the ZIP file.
2. Open the `medicare_project` folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the VS Code Live Server extension.

## Features
- Responsive home page and navigation
- Search medicines by name or use
- Filter by category
- View medicine use and safety notes
- Contact form demonstration

## Important
This is an educational demonstration only. It is not a pharmacy, diagnostic tool or prescribing service. Medicine details are brief examples and must be checked against reliable, current clinical sources before real-world use. No dose instructions are provided. The contact form is front-end only and does not transmit or store messages.
